package com.QuizService.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.QuizService.Entitites.Quiz;
import com.QuizService.Repository.QuizRepository;

@Service
public class QuizServiceImplementation implements QuizService {

	private QuizRepository quizRepository;
	
	
	private QuestionClient questionClient;
	

	

	public QuizServiceImplementation(QuizRepository quizRepository, QuestionClient questionClient) {
		super();
		this.quizRepository = quizRepository;
		this.questionClient = questionClient;
	}

	@Override
	public Quiz add(Quiz quiz) {

		return quizRepository.save(quiz);
	}

	@Override
	public List<Quiz> get() {
//		return quizRepository.findAll();
		  List<Quiz> quizzes = quizRepository.findAll();

	        List<Quiz> newQuizList = quizzes.stream().map(quiz -> {
	            quiz.setQuestions(questionClient.getQuestionOfQuiz(quiz.getId()));
	            return quiz;
	        }).collect(Collectors.toList());

	        return newQuizList;
	}

	@Override
	public Quiz get(Long id) {
//		return quizRepository.findById(id).orElseThrow(() -> new RuntimeException("no quiz found"));
		  Quiz quiz = quizRepository.findById(id).orElseThrow(() -> new RuntimeException("Quiz not found"));
	        quiz.setQuestions(questionClient.getQuestionOfQuiz(quiz.getId()));
	        return quiz;
	
	}

}
