package com.QuestionService.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.QuestionService.Entities.Question;
import com.QuestionService.Service.QuestionServiceImplementation;

@RestController
@RequestMapping("/question")
public class QuestoinController {
	
	@Autowired
	private QuestionServiceImplementation questionServiceImplementation;
	
	@PostMapping
	public Question add(@RequestBody Question question) {
		return questionServiceImplementation.create(question);
	}
	
	@GetMapping
	public List<Question> getAll(){
		return questionServiceImplementation.getall();
	}
	
	@GetMapping("/{id}")
	public Question getById(@PathVariable Long id) {
		return questionServiceImplementation.getById(id);
	}
	
	@GetMapping("quiz/{quizId}")
	public List<Question> getQuestionOfQuiz(@PathVariable Long quizId){
		return questionServiceImplementation.getQuestionsOfQuiz(quizId);
	}
	

}
