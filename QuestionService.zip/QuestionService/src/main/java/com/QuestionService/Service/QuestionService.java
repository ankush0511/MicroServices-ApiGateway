package com.QuestionService.Service;

import java.util.List;

import com.QuestionService.Entities.Question;

public interface QuestionService {

	
	Question create(Question question);
	
	List<Question> getall();
	
	Question getById(Long id);
	
	List<Question> getQuestionsOfQuiz(Long quizId);
	
}
