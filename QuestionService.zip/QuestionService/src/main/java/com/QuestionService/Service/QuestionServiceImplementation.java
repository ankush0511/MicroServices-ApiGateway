package com.QuestionService.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.QuestionService.Entities.Question;
import com.QuestionService.Repository.QuestionRepository;

@Service
public class QuestionServiceImplementation implements QuestionService {

	@Autowired
	private QuestionRepository questionRepository;

	@Override
	public Question create(Question question) {
		// TODO Auto-generated method stub
		return questionRepository.save(question);
	}

	@Override
	public List<Question> getall() {
		return questionRepository.findAll();
	}

	@Override
	public Question getById(Long id) {
		return questionRepository.findById(id).orElseThrow(() -> new RuntimeException("No question found"));
	}

	@Override
	public List<Question> getQuestionsOfQuiz(Long quizId) {
		return questionRepository.findByQuizId(quizId);  
	}

}
