package com.QuestionService.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.QuestionService.Entities.Question;

public interface QuestionRepository extends JpaRepository<Question, Long>{

	List<Question> findByQuizId(Long quizId);
	
}
