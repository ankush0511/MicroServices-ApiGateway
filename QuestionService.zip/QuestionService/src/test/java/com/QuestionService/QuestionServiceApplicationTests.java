package com.QuestionService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
